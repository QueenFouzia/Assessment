﻿using CodeAssessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Xml.Linq;

namespace CodeAssessment.Controllers
{
    public class ReadAssessmentManagerController : ApiController
    {
        /// <summary>
        /// ApiController - GetAllPatients 
        /// Gives the list of Patients Assessment Records
        /// </summary>
        /// <returns></returns>
        public List<PatientModel> GetAllPatients()
        {
            List<PatientModel> patients = new List<PatientModel>();
            XDocument doc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/Patient.xml"));

            foreach (XElement element in doc.Descendants("Patient").Descendants("Item"))
            {
                PatientModel patient = new PatientModel();

                patient.Forename = element.Element("Forename").Value;
                patient.Surname = element.Element("Surname").Value;
                patient.Gender = element.Element("Gender").Value;
                patient.DOB = element.Element("DateOfBirth").Value;
                

                patients.Add(patient);
            }
            return patients;

        }

    }
}
