﻿using CodeAssessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Xml.Linq;

namespace CodeAssessment.Controllers
{
    public class CreateAssessmentManagerController : ApiController
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="patient"></param>
        /// <returns></returns>
        [HttpPost]
        public string SavePatient(PatientModel patient)
        {

            XDocument doc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/Patient.xml"));
            var patientNode = doc.Descendants("Patient").FirstOrDefault();
            if (patientNode != null)
            {
                patientNode.Add(new XElement("Item",
                         new XElement("Forename", patient.Forename),
                         new XElement("Surname", patient.Surname),
                         new XElement("Gender", patient.Gender),
                         new XElement("DateOfBirth", String.Format("{0:d/M/yyyy}", patient.DOBDateTime)),
                         new XElement("TelephoneNumber",
                                new XElement("HomeNumber", patient.HomeNumber != null ? patient.HomeNumber : ""),
                                new XElement("WorkNumber", patient.WorkNumber != null ? patient.WorkNumber : ""),
                                new XElement("MobileNumber", patient.MobileNumber != null ? patient.MobileNumber : ""))
                                ));

            }
            doc.Save(HttpContext.Current.Server.MapPath("~/App_Data/Patient.xml"));

            return "true";
        }
    }
}
