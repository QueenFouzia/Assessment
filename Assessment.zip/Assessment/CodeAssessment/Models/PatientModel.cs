﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CodeAssessment.Models
{
    public class PatientModel
    {
        /// <summary>
        /// ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Forename
        /// </summary>
        [Required(ErrorMessage = "Forename is required")]
        public string Forename { get; set; }

        /// <summary>
        /// Surname
        /// </summary>
        [Required(ErrorMessage = "Surname is required")]
        public string Surname { get; set; }

        /// <summary>
        /// DOBDateTime
        /// </summary>
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{mm/dd/yyyy}")]
        [Display(Name = "DOB")]
        public DateTime? DOBDateTime { get; set; }

        /// <summary>
        /// Gender
        /// </summary>
        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; }

        /// <summary>
        /// DOB
        /// </summary>
        public string DOB { get; set; }

        /// <summary>
        /// HomeNumber
        /// </summary>
        [Display(Name = "Home Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid Home number")]
        public string HomeNumber { get; set; }

        /// <summary>
        /// MobileNumber
        /// </summary>
        [Display(Name = "Mobile Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid Mobile number")]
        public string MobileNumber { get; set; }

        /// <summary>
        /// WorkNumber
        /// </summary>
        [Display(Name = "Work Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid Work number")]
        public string WorkNumber { get; set; }
    }
}