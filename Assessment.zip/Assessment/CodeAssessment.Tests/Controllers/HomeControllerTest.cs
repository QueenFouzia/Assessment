﻿using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CodeAssessment;
using CodeAssessment.Controllers;
using CodeAssessment.Models;
using System;

namespace CodeAssessment.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Home Page", result.ViewBag.Title);
        }

        public void TestAddPatientForRequiredFieldsSuccess()
        {
            //Arrange
            HomeController controller = new HomeController();
            PatientModel patientMoc = new PatientModel()
            {
                Forename = "William James",
                Surname = "WJ",
                DOBDateTime = DateTime.Now,
                Gender = "F"
            };

            //Act
            ViewResult result = controller.AddPatient(patientMoc) as ViewResult;

            //Assert
            Assert.AreEqual("Add Patient", result.ViewBag.Title);
        }

        public void TestAddPatientForRequiredFieldsFailure()
        {
            //Arrange
            HomeController controller = new HomeController();
            PatientModel patientMoc = new PatientModel()
            {
                Forename = "William James",
                Surname = "WJ",
                DOBDateTime = DateTime.Now,
                Gender = ""
            };

            //Act
            ViewResult result = controller.AddPatient(patientMoc) as ViewResult;

            //Assert
            Assert.AreEqual("Add Patient", result.ViewBag.Title);
        }
    }
}
