﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CodeAssessment.Controllers;
using CodeAssessment.Models;

namespace CodeAssessment.Tests.Controllers.APIController
{
    [TestClass]
    public class CreateAssessmentManagerControllerTest
    {
        /// <summary>
        /// SaveAssessment
        /// </summary>
        [TestMethod]
        public void SaveAssessment()
        {
            //Arrange
            CreateAssessmentManagerController cAMController = new CreateAssessmentManagerController();

            PatientModel patientMoc = new PatientModel()
            {
                Forename = "William James",
                Surname = "WJ",
                DOBDateTime = DateTime.Now,
                Gender = "",
                HomeNumber = "9876543212",
                WorkNumber = "0809765434",
                MobileNumber = "8765432145"
            };
            var result = cAMController.SavePatient(patientMoc);

            //Assert
            Assert.IsNotNull(result.Length != 0);
        }
    }
}
